-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 26, 2016 at 02:52 PM
-- Server version: 5.5.44-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `madpaws_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_chats`
--

CREATE TABLE IF NOT EXISTS `booking_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_request_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_role` enum('Basic','Sitter') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `booking_chats`
--

INSERT INTO `booking_chats` (`id`, `booking_request_id`, `message`, `user_id`, `user_role`, `created_at`) VALUES
(1, 2, 'please book my order', 29, 'Basic', '2016-05-19 05:24:55'),
(2, 2, 'okay we will book ur oder. thanks', 37, 'Sitter', '2016-05-19 05:25:20'),
(3, 3, 'I have quesry regarding booking.', 43, 'Basic', '2016-05-19 05:26:11'),
(4, 3, 'yes please ask ur queries', 37, 'Sitter', '2016-05-19 05:26:11'),
(5, 2, 'is it booked?', 29, 'Basic', '2016-05-19 09:09:51'),
(6, 2, 'yes Congrats its booked :) yippieee!!', 37, 'Sitter', '2016-05-19 09:32:05'),
(17, 2, 'this is nice one. I m siter here', 37, 'Sitter', '2016-05-19 10:34:54'),
(18, 2, 'I am sitter here again .s orry', 37, 'Sitter', '2016-05-19 10:35:04'),
(19, 2, 'this is realy nice looking..', 37, 'Sitter', '2016-05-19 10:48:53'),
(22, 2, 'testtt2', 0, 'Basic', '2016-05-20 07:30:27'),
(23, 2, 'testsd 3', 0, 'Sitter', '2016-05-20 07:33:18'),
(24, 2, 'test', 38, 'Sitter', '2016-05-20 07:34:56'),
(25, 3, 'heeelo', 38, 'Basic', '2016-05-20 10:02:51'),
(26, 3, 'dfg', 38, 'Basic', '2016-05-20 10:02:57'),
(27, 3, 'teseeer', 38, 'Basic', '2016-05-20 11:23:35'),
(28, 2, 'this is testing message here', 38, 'Basic', '2016-05-20 12:00:13');

-- --------------------------------------------------------

--
-- Table structure for table `booking_requests`
--

CREATE TABLE IF NOT EXISTS `booking_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `sitter_id` int(11) NOT NULL,
  `booknig_start_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `booking_end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `guest_id_for_bookinig` varchar(255) NOT NULL,
  `recieved_photo_during_stay` tinyint(4) NOT NULL,
  `required_service` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `booking_requests`
--

INSERT INTO `booking_requests` (`id`, `user_id`, `sitter_id`, `booknig_start_date`, `booking_end_date`, `guest_id_for_bookinig`, `recieved_photo_during_stay`, `required_service`, `message`, `status`, `created_date`, `modified_date`) VALUES
(1, 29, 65, '2016-05-18 09:50:27', '2016-05-24 18:30:00', '1,5,9', 1, 'Drop Visit', 'Testing here', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 29, 37, '2016-05-18 10:19:40', '2016-05-26 18:30:00', '2,5,9,12', 1, 'House Sitting', 'hteinsdf', 1, '2016-05-17 23:48:09', '0000-00-00 00:00:00'),
(3, 43, 37, '2016-05-18 10:19:49', '2016-05-19 18:30:00', '', 0, '', 'this is another query here', 0, '2016-05-17 20:34:05', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
