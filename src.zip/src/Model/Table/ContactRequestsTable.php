<?php 
namespace App\Model\Table;

use Cake\ORM\Table;

class ContactRequestsTable extends Table
{

}
?>