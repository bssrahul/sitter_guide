<?php 
namespace App\Model\Entity;
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;


class userSitterHouse extends Entity
{
    use TranslateTrait;
}
?>