<?php 
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;
class Category extends Entity
{
    use TranslateTrait;
}
?>