<?php 
namespace App\Model\Entity;
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;


class PromoCode extends Entity
{
    use TranslateTrait;
}
?>