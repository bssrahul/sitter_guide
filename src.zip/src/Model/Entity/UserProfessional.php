<?php 

use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;
class UserProfessional extends Entity
{
    use TranslateTrait;
}


?>