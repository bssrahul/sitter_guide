<?php 
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;
class CmsPage extends Entity
{
    use TranslateTrait;
}
?>