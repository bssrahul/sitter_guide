<?php 
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;
class SiteConfigurations extends Entity
{
    use TranslateTrait;
}
?>