<?php 
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;
class Admin extends Entity
{
    use TranslateTrait;
}
?>