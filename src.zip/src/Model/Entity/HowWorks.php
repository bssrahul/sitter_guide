<?php 
use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;
class HowWorks extends Entity
{
    use TranslateTrait;
}
?>